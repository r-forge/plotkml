# Purpose        : Generic method to plot time-series in Google Earth 
# Maintainer     : Tomislav Hengl (tom.hengl@wur.nl); 
# Contributions  : ;
# Dev Status     : Alpha
# Note           : it requires a single point only;


# end of script;