# Purpose        : derivation of colour palettes for visualization of environmental data
# Maintainer     : Tomislav Hengl (tom.hengl@wur.nl)
# Contributions  : Pierre Roudier (pierre.roudier@landcare.nz)
# Status         : not tested yet
# Note           : These functions could be converted to a stand-alone package;

library(XML)
library(RColorBrewer)
library(colorspace)

# additional functions:
source(url('http://r-forge.r-project.org/scm/viewvc.php/*checkout*/branches/views/R/utils_other.R?root=plotkml'))

# read SAGA palettes:
sprm.lst <- list.files(path = ".", pattern="*.sprm")
sprm.lst <- sprm.lst[order(as.integer(sapply(sprm.lst, strsplit, ".sprm")))]
# each colour pallete consists of 20 colours
sprm.lst

# read each sprm file and generate a palette in hex system:
rgb.tbl <- data.frame(R=NA, G=NA, B=NA)
SAGA_pal <- NULL
for(i in 1:length(sprm.lst)){
    tmp <- xmlTreeParse(sprm.lst[i], useInternalNodes = TRUE)
    cols <- xmlRoot(tmp)[[9]]
    col.lst <- sapply(sapply(xmlChildren(cols), function(x) x), xmlValue)
    for(j in 1:20){
    rgb.tbl[j,c("R","G","B")] <- as.integer(substr(strsplit(col.lst[j], " ")[[1]], start=2, stop=4))/255
    }
    SAGA_pal[[i]] <- rgb(rgb.tbl)
}

names(SAGA_pal) <- c(
"SG_COLORS_DEFAULT",   #1
"SG_COLORS_DEFAULT_BRIGHT", #2
"SG_COLORS_WHITE_BLACK",  #3
"SG_COLORS_RED_BLACK",  #4
"SG_COLORS_GREEN_BLACK",  #5
"SG_COLORS_BLUE_BLACK", #6
"SG_COLORS_WHITE_RED",  #7
"SG_COLORS_WHITE_GREEN",  #8
"SG_COLORS_WHITE_BLUE", #9
"SG_COLORS_YELLOW_RED", #10
"SG_COLORS_YELLOW_GREEN", #11
"SG_COLORS_YELLOW_BLUE",  #12
"SG_COLORS_GREEN_RED",  #13
"SG_COLORS_BLUE_RED", #14
"SG_COLORS_BLUE_GREEN", #15
"SG_COLORS_BLUE_GREY_RED",  #16
"SG_COLORS_GREEN_GREY_RED", #17
"SG_COLORS_BLUE_GREY_GREEN",  #18
"SG_COLORS_BLUE_GREEN_RED", #19
"SG_COLORS_RED_BLUE_GREEN", #20
"SG_COLORS_GREEN_RED_BLUE", #21
"SG_COLORS_RAINBOW")  #22

# plot all palletes above each other:

windows.options(width=2.2, height=9)
par(mfrow=c(11,1))
par(mar=c(1.5,.8,1.5,.5))
for(j in c(1,2,7,8,10,11,17,18,19,21,22)){
    plot(y=rep(1, length(SAGA_pal[[j]])), x=1:length(SAGA_pal[[j]]), axes=FALSE, xlab='', ylab='', pch=15, cex=1.5, col=SAGA_pal[[j]])
    mtext(names(SAGA_pal)[j], cex=.5, side=3)
}

save(SAGA_pal, file="SAGA_pal.rda")

# Worldmaps palettes:
PAL.lst <- list.files(path = ".", pattern="*.PAL")
PAL.lst
# read RGB values and convert to hex:
worldgrids_pal <- NULL
for(j in 1:length(PAL.lst)){
  tmp <- read.table(PAL.lst[j], col.names=c("class","R","G","B"))
  nms <- t(matrix((unlist(strsplit(readLines(set.file.extension(PAL.lst[j], ".rdc")), split=": "))), ncol=2, byrow=T))
  nms.meta <- unclass(nms[2,])
  worldgrids_pal[[j]] <- rgb(tmp[,c("R","G","B")]/255)
  names(worldgrids_pal[[j]]) <- nms.meta[-c(1:36)]
}

names(worldgrids_pal) <- paste(unlist(sapply(PAL.lst, strsplit, ".PAL")))
# worldgrids_pal[[4]]

save(worldgrids_pal, file="worldgrids_pal.rda")


# Standard soil vars color legends
# e.g. soil organic carbon:
soc.pal <- mix5cols(color1=RGB(0.706, 0.804, 0.804), color2=RGB(0.663, 0.663, 0.663), color3=RGB(0, 0.392, 0), color4=RGB(0.0,0.1,0.0), color5=RGB(0,0,0), break1=.2, break2=.4, break3=.6, no.col=20)
# soil pH:
pH.pal <- hsv(seq(0,1,by=1/27))[1:20]
# texture fractions:
tex.pal <- mix3cols(color1=RGB(1,0.843,0), color2=RGB(0.5451,0.353,0.169), color3=RGB(0,0,0), break1=.6, no.col=20)
## HCL examples from [http://cran.r-project.org/web/packages/colorspace/vignettes/hcl-colors.pdf]
blue_grey_red <- diverge_hcl(20, c = c(100, 0), l = c(50, 90), power = 1.3)
grey_black <- rev(sequential_hcl(20, c = 0, power = 2.2))

# Other popular R palletes for continuous variables:

R_pal <- NULL
R_pal[[1]] <- rev(rainbow(27)[1:20]) 
R_pal[[2]] <- rev(heat.colors(20))
R_pal[[3]] <- terrain.colors(20)
R_pal[[4]] <- topo.colors(20)
R_pal[[5]] <- rev(bpy.colors(20))
R_pal[[6]] <- soc.pal
R_pal[[7]] <- pH.pal
R_pal[[8]] <- tex.pal
R_pal[[9]] <- blue_grey_red
R_pal[[10]] <- grey_black

names(R_pal) <- c("rainbow_75", "heat_colors", "terrain_colors", "topo_colors", "bpy_colors", "soc_pal", "pH_pal", "tex_pal", "blue_grey_red", "grey_black")

save(R_pal, file="R_pal.rda")

# end of script;